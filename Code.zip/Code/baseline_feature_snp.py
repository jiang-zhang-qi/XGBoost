import pandas as pd 
import numpy as np
from sklearn.model_selection import train_test_split, KFold, GridSearchCV, cross_val_score
from xgboost import XGBClassifier
from sklearn import metrics
import matplotlib.pyplot as plt

#read data
df = pd.read_csv('new_feature_snp_data.csv')

#split data (feature and snp)
X = df.iloc[:, 2:78]
y = df.iloc[:, -1]
y = pd.DataFrame(y)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 5, stratify = y)

#set the parameters of XGBClassifier
xgb_f = XGBClassifier(learning_rate=0.01, n_estimators=277, max_depth=5, min_child_weight=1, gamma=0.5,
                    subsample=0.65, colsample_bytree=0.9, objective= 'binary:logistic', scale_pos_weight=1,
                    seed=27)

#训练集用5Fold和cross_validation_score计算AUC
kfold = KFold(n_splits=5, random_state=7)
results = cross_val_score(xgb_f, X_train, y_train.values.ravel(), cv=kfold, scoring='roc_auc')
print(results.mean())		#0.737071430703511

#测试集上计算AUC值
xgb_f.fit(X_train, y_train.values.ravel())
pred = xgb_f.predict_proba(X_test)[:,1]
fpr, tpr, threshold = metrics.roc_curve(y_test.values.ravel(), pred)
roc_auc = metrics.auc(fpr, tpr)		
print(roc_auc)		#AUC = 0.6976760082023239

#draw roc_curve
plt.figure()
lw = 2
plt.figure(figsize=(10,10))
plt.plot(fpr, tpr, color='darkorange',
         lw=lw, label='ROC curve (area = %0.2f)' % roc_auc) 
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.0])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")
plt.show()