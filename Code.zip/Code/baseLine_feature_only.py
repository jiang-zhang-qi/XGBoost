import pandas as pd 
import numpy as np
from sklearn.model_selection import train_test_split, KFold, GridSearchCV, cross_val_score
from xgboost import XGBClassifier
from sklearn import metrics
import matplotlib.pyplot as plt


#划分数据集
#已取交集1214个Samples
df = pd.read_csv('new_feature_snp_data.csv')	
X = df.iloc[:, 2:74]
y = df.iloc[:, -1]
y = pd.DataFrame(y)
#stratify=y这个参数可以让0、1在训练集和测试集中的比例近似
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 5, stratify = y)
	#保险起见将训练集与测试集全部导出，算了一下0，1比例其中测试集约为0.5369， 训练集约为0.4634		
# train_set = pd.concat([X_train, y_train], axis = 1)
# test_set = pd.concat([X_test, y_test], axis = 1)
# train_set.to_csv('train_set.csv', index = True, header = True)
# test_set.to_csv('test_set.csv', index = True, header = True)

#分参数类别，进行分步调参，可能会导致算法收敛于局部最优解
#调参过程较长在jupyter notebook上完成的
#以下是调完参数后的XGBoost

xgb_f = XGBClassifier(learning_rate=0.01, n_estimators=277, max_depth=5, min_child_weight=1, gamma=0.5,
    				subsample=0.65, colsample_bytree=0.9, objective= 'binary:logistic', scale_pos_weight=1,
    				seed=27)

#计算训练集的AUC值，使用5Fold cross_validation
kfold = KFold(n_splits=5, random_state=7)
results = cross_val_score(xgb_f, X_train, y_train.values.ravel(), cv=kfold, scoring='roc_auc')
print(results.mean())		#0.7241887534252218

#忽略虚线内的东西:-)
#----------------------------------------------------------------------------------------------------
#本来以为test_data里算auc时用的是概率，想来应该和cross_val_score里算出来的有区别，特此验证了一下
# aucs = []
# cv = KFold(n_splits = 5, random_state = 7)
# for train, test in cv.split(X_train, y_train):
#     probas_ = xgb_f.fit(X_train.iloc[train], y_train.iloc[train]).predict_proba(X_train.iloc[test])
#     fpr, tpr, threshold = metrics.roc_curve(y_train.iloc[test], probas_[:, 1])
#     roc_auc = metrics.auc(fpr, tpr)
#     aucs.append(roc_auc)
# print(sum(aucs)/5)
#结果发现是一样的……
#----------------------------------------------------------------------------------------------------

#对测试集进行预测
xgb_f.fit(X_train, y_train.values.ravel())
pred = xgb_f.predict_proba(X_test)[:,1]
#计算fpr和tpr
fpr, tpr, threshold = metrics.roc_curve(y_test.values.ravel(), pred)
#计算AUC
roc_auc = metrics.auc(fpr, tpr)		#0.6847573479152426
#绘制ROC_Curve
plt.figure()
lw = 2
plt.figure(figsize=(10,10))
plt.plot(fpr, tpr, color='darkorange',
         lw=lw, label='ROC curve (area = %0.2f)' % roc_auc) 
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.0])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")
plt.show()