import pandas as pd 

#read files
data_feature_snp = pd.read_csv('data_feature_snp.csv')
data_ln_num = pd.read_csv('ln_num.csv')
data_snp = pd.read_csv('plink.raw', sep=' ')

#利用病理号，将Ln xxx 对应好
for i in range(0, 1389):
    for j in range(0, 1694):
        a = data_ln_num.loc[i, '病理号']
        b = int(data_feature_snp.loc[j, '病理号'])
        if a == b:
            c = data_ln_num.loc[i, '序号']
            data_feature_snp.loc[j, '序号'] = c

#再利用Ln xxx把snp对应好
for i in range(0, 1286):
    for j in range(0, 1694):
        a = data_snp.loc[i, 'IID']
        b = data_feature_snp.loc[j, '序号']
        if a == b:
            x1 = data_snp.loc[i, 'JHU_2.56172645_A']
            x2 = data_snp.loc[i, 'kgp2675668_A']
            x3 = data_snp.loc[i, 'rs1891729_A']
            x4 = data_snp.loc[i, 'kgp10046072_A']
            data_feature_snp.loc[j, 'JHU_2.56172645_A'] = x1
            data_feature_snp.loc[j, 'kgp2675668_A'] = x2
            data_feature_snp.loc[j, 'rs1891729_A'] = x3
            data_feature_snp.loc[j, 'kgp10046072_A'] = x4

#save cleared data
data1.to_excel('new_feature_snp_data.xlsx')