import pandas as pd 
import numpy as np
from sklearn.model_selection import train_test_split, KFold, GridSearchCV, cross_val_score
from xgboost import XGBClassifier
from sklearn import metrics
import matplotlib.pyplot as plt

#read data
df = pd.read_csv('new_feature_snp_data.csv')
#只读snp数据
X = df.iloc[:, 74:78]
y = df.iloc[:, -1]
y = pd.DataFrame(y)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 5, stratify = y)

#没有调参之前的AUC值
# xgb_f = XGBClassifier(learning_rate=0.01, n_estimators=277, max_depth=5, min_child_weight=1, gamma=0.5,
#                     subsample=0.65, colsample_bytree=0.9, objective= 'binary:logistic', scale_pos_weight=1,
#                     seed=27)
# kfold = KFold(n_splits=5, random_state=7)
# results = cross_val_score(xgb_f, X_train, y_train.values.ravel(), cv=kfold, scoring='roc_auc')
# print(results.mean())		
##0.6086834243558427

#调参过程-----------------------------------------------------------------------------------------------
# #1.先调整learning_rate and n_estimators
# param_test1 = {
#     'learning_rate':[i/100.0 for i in range(1, 20)],
#     'n_estimators':range(100, 1000, 100)
# }
# gsearch1 = GridSearchCV(estimator = XGBClassifier(learning_rate=0.01, n_estimators=277, max_depth=5, min_child_weight=1, gamma=0.5,
#                     subsample=0.65, colsample_bytree=0.9, objective= 'binary:logistic', scale_pos_weight=1,
#                     seed=27), param_grid=param_test1, scoring='roc_auc',
#                     iid=False, cv=5)
# gsearch1.fit(X_train, y_train.values.ravel())
# gsearch1.best_params_, gsearch1.best_score_		#({'learning_rate': 0.01, 'n_estimators': 100}, 0.6169250782224989)

# #2.再调整max_depth and min_child_weight
# param_test2 = {
#     'max_depth':range(3, 10, 2),
#     'min_child_weight':range(1, 6, 2)
# }
# gsearch2 = GridSearchCV(estimator = XGBClassifier(learning_rate=0.01, n_estimators=100, max_depth=5, min_child_weight=1, gamma=0.5,
#                     subsample=0.65, colsample_bytree=0.9, objective= 'binary:logistic', scale_pos_weight=1,
#                     seed=27), param_grid=param_test2, scoring='roc_auc',
#                     iid=False, cv=5)
# gsearch2.fit(X_train, y_train.values.ravel())
# gsearch2.best_params_, gsearch2.best_score_		#({'max_depth': 5, 'min_child_weight': 5}, 0.6212944780194825)

# param_test3 = {
#     'max_depth':[4, 5, 6],
#     'min_child_weight':[4, 5, 6]
# }
# gsearch3 = GridSearchCV(estimator = XGBClassifier(learning_rate=0.01, n_estimators=100, max_depth=5, min_child_weight=1, gamma=0.5,
#                     subsample=0.65, colsample_bytree=0.9, objective= 'binary:logistic', scale_pos_weight=1,
#                     seed=27), param_grid=param_test3, scoring='roc_auc',
#                     iid=False, cv=5)
# gsearch3.fit(X_train, y_train.values.ravel())
# gsearch3.best_params_, gsearch3.best_score_		#({'max_depth': 4, 'min_child_weight': 6}, 0.622455579561416)

# #3.调整gamma防止过拟合
# param_test4 = {
#     'gamma':[i/10 for i in range(0, 8)]
# }
# gsearch4 = GridSearchCV(estimator = XGBClassifier(learning_rate=0.01, n_estimators=100, max_depth=4, min_child_weight=6, gamma=0.5,
#                     subsample=0.65, colsample_bytree=0.9, objective= 'binary:logistic', scale_pos_weight=1,
#                     seed=27), param_grid=param_test4, scoring='roc_auc',
#                     iid=False, cv=5)
# gsearch4.fit(X_train, y_train.values.ravel())
# gsearch4.best_params_, gsearch4.best_score_		#({'gamma': 0.3}, 0.6241733052836048)

# #4.subsample and colsample_bytree
# param_test5 = {
#     'subsample':[i/100.0 for i in range(50, 71, 5)],
#     'colsample_bytree':[i/100.0 for i in range(70, 91, 5)]
# }
# gsearch5 = GridSearchCV(estimator = XGBClassifier(learning_rate=0.01, n_estimators=100, max_depth=4, min_child_weight=6, gamma=0.3,
#                     subsample=0.65, colsample_bytree=0.9, objective= 'binary:logistic', scale_pos_weight=1,
#                     seed=27), param_grid=param_test5, scoring='roc_auc',
#                     iid=False, cv=5)
# gsearch5.fit(X_train, y_train.values.ravel())
# gsearch5.best_params_, gsearch5.best_score_		#({'colsample_bytree': 0.75, 'subsample': 0.55}, 0.6257397406501058)

# #5.重新调整n_estimators
# param_test6 = {
#     'n_estimators':range(80, 120, 10)
# }
# gsearch6 = GridSearchCV(estimator = XGBClassifier(learning_rate=0.01, n_estimators=100, max_depth=4, min_child_weight=6, gamma=0.3,
#                     subsample=0.55, colsample_bytree=0.75, objective= 'binary:logistic', scale_pos_weight=1,
#                     seed=27), param_grid=param_test6, scoring='roc_auc',
#                     iid=False, cv=5)
# gsearch6.fit(X_train, y_train.values.ravel())
# gsearch6.best_params_, gsearch6.best_score_		#({'n_estimators': 90}, 0.6259120434272372)
#调参过程-----------------------------------------------------------------------------------------------

#调完参数的model
xgb_f = XGBClassifier(learning_rate=0.01, n_estimators=90, max_depth=4, min_child_weight=6, gamma=0.3,
                    subsample=0.55, colsample_bytree=0.75, objective= 'binary:logistic', scale_pos_weight=1,
                    seed=27)
#训练集上计算AUC值
kfold = KFold(n_splits=5, random_state=7)
results = cross_val_score(xgb_f, X_train, y_train.values.ravel(), cv=kfold, scoring='roc_auc')
print(results.mean())		#0.625452120896673

#所以我们调整参数后AUC值：0.6086834243558427 --> 0.625452120896673

#训练集上计算AUC值
xgb_f.fit(X_train, y_train.values.ravel())
pred = xgb_f.predict_proba(X_test)[:,1]
fpr, tpr, threshold = metrics.roc_curve(y_test.values.ravel(), pred)
roc_auc = metrics.auc(fpr, tpr)
print(roc_auc)		#0.6175666438824333

#draw roc_curve
plt.figure()
lw = 2
plt.figure(figsize=(10,10))
plt.plot(fpr, tpr, color='darkorange',
         lw=lw, label='ROC curve (area = %0.2f)' % roc_auc) 
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.0])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")
plt.show()












